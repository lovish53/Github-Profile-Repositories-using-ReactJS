import { useState } from "react"
import LoadingBar from 'react-top-loading-bar'

function App() {
  const [username, setUsername] = useState('')
  const [repositories, setRepositories] = useState([])
  const [profileData, setProfileData] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [progress, setProgress] = useState(0)

  const recordsPerPage = 10;
  const lastIndex = currentPage * recordsPerPage;
  const firstIndex = lastIndex - recordsPerPage;
  const records = repositories.slice(firstIndex, lastIndex);
  const npage = Math.ceil(repositories.length / recordsPerPage);
  const numbers = [...Array(npage + 1).keys()].slice(1)

  function showRepositories(e) {
    e.preventDefault()
    setProgress(10)
    fetch(`https://api.github.com/users/${username}`).then((result) => { return result.json() }).then((languagesData) => {
      setProfileData(languagesData)
      //   console.log(languagesData)
      setProgress(50)
      fetch(`https://api.github.com/users/${username}/repos`).then((result) => { return result.json() }).then((data) => {
        setRepositories(data)
        //console.log(data)      
      })
    })
    setProgress(100)      
  }
  function prevPage(e) {
    setProgress(0)
    e.preventDefault()
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1)
    }
    setProgress(100)
  }
  function changeCPage(id, e) {
    e.preventDefault()
    setCurrentPage(id)
    setProgress(100)
  }
  function nextPage(e) {
    e.preventDefault()
    if (currentPage !== npage) {
      setCurrentPage(currentPage + 1)
    }
    setProgress(100)
  }

  return (

    <div className="container-fluid">
      <div className="row">
        <div className="col-md-12">
          <LoadingBar
            color='#f11946'
            height={4}
            progress={progress}
            onLoaderFinished={() => setProgress(0)}
          />
          <section id="search-bar" className="search-bar-md">
            <h1 style={{ paddingLeft: "60px" }}>Github Repositories</h1>
            <input type="text" className="form-control" placeholder="Search Github Profile" value={username} onChange={(e) => { setUsername(e.target.value) }} />
            <button type="search" className="btn btn-danger" onClick={(e) => { showRepositories(e) }}>Search</button>
          </section>
          {profileData ?
            <>
              <section id="profile">
                <figure>
                  <img src={profileData.avatar_url} className="image-fluid md" alt=""></img>
                  <figcaption ><a href={profileData.html_url} style={{ textDecoration: "none", color: "white" }}>{profileData.html_url}</a></figcaption>
                </figure>
                <article id="article">
                  <h2><strong>{profileData.name}</strong></h2>
                  {profileData.bio ?
                    <>
                      <p><strong>BIO:{' '}<i>{profileData.bio}</i></strong></p>
                    </>
                    :
                    <p></p>
                  }
                  {profileData.location ? <>
                    <p><i className="bi bi-geo-alt"></i>:{profileData.location}</p>
                  </>
                    :
                    <p></p>
                  }
                  {profileData.twitter_username ? <>
                    <p><i className="bi bi-twitter"></i>:{profileData.twitter_username}</p>
                  </>
                    :
                    <p></p>}
                </article>

              </section>
              <section id="items">
            {records.map((result, key) => (
              <article key={result.id}>
                <h3><a href={result.html_url} target="_blank" rel="noreferrer" style={{textDecoration:"none", color:"blue"}}>{result.name}</a></h3>
                {result.description ?
                  <>
                    <p><strong>Description : {result.description}</strong></p>
                  </>
                  :
                  <p><strong>Description : No Description available</strong></p>
                }
                {result.language ? <>
                  <p><strong>Languages: {result.language}</strong></p>
                </>
                  :
                  <p><strong>Languages: No Languages Mentioned</strong></p>
                }
                <hr></hr>
              </article>

            ))}
          </section>
          <nav>
              <ul className="pagination">
                <li className="page-item">
                  <button className="page-link" onClick={(e) => { prevPage(e) }} disabled={currentPage===1}>Prev</button>
                </li>
                {
                  numbers.map((result, key) => (
                    <li className={`page-item ${currentPage === result ? 'active' : ''} `} key={key}>
                      <button className="page-link"
                        onClick={(e) => { changeCPage(result, e) }}>{result}</button>
                    </li>
                  ))
                }
                <li className="page-item">
                  <button className="page-link" onClick={(e) => { nextPage(e) }} disabled={currentPage===npage}>Next</button>
                </li>
              </ul>
            </nav>
            </>
            :
            <></>     
          }
        </div>
      </div>
    </div>

  );
}

export default App;